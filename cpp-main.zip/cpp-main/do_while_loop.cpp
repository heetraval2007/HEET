//Do while loop 
#include<iostream>
#include<conio.h>
using namespace std;
int main(){
    int s=10;
    clrscr();
    do{
        cout <<s<<"\n";
        s--;
    }while(s>0);
    getch();
    return 0;
}